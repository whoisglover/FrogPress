// Dimensions
CKEDITOR.config.height = 400;
CKEDITOR.config.width = "auto";

// Functionality
CKEDITOR.config.toolbar = [[ 'Bold', 'Italic', 'Underline'],];
CKEDITOR.config.entities = false;
CKEDITOR.config.enterMode = CKEDITOR.ENTER_BR;

// Aesthetics
CKEDITOR.config.uiColor = "#ADB6BA";
